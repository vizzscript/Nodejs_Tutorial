// Variable store number data type
let a = 35;
console.log(typeof a);

// Variable store string data type
a = "Pinnacle";
console.log(typeof a);

// Variable store Boolean data type
a = true;
console.log(typeof a);

// Variable store undefined (no value) data type
a = undefined;
console.log(typeof a);
