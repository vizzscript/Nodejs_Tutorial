let company = {
    Name: "Pinnacle",
    Address: "Nagpur",
    Contact: "+919876543210",
    Email: "abc@pinnacle.in"
};

// Display the object information
console.log("Information of variable company:", company);

console.log("Information of variable company:", company["Name"]);
// Display the type of variable
console.log("Type of variable company:", typeof company);
