function multiply(num1, num2) {

    // It returns the multiplication
    // of num1 and num2
    return num1 * num2;
}

// Declare variable
let x = 2;
let y = 3;

// Display the answer returned by
// multiply function
console.log("Multiplication of", x,
    "and", y, "is", multiply(x, y));
